"use strict";

export default { //存放变量的容器
	baseUrl: 'http://107.148.39.21/api/',
	fileUrl: 'http://107.148.39.21'
}
